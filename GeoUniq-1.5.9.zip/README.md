https://gitlab.com/geouniq/documentation/blob/master/sdk/integration/ios.md

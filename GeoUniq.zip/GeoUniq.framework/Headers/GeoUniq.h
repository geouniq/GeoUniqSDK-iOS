//
//  GeoUniq.h
//  GeoUniq
//
//  Created by Antonio Romano on 29/01/15.
//  Copyright (c) 2015 GeoUniq. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double GeoUniqVersionNumber;
FOUNDATION_EXPORT const unsigned char GeoUniqVersionString[];